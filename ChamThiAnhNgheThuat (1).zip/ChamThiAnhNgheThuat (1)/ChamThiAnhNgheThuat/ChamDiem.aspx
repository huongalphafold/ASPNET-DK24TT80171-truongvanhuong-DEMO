﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ChamDiem.aspx.cs" Inherits="ChamThiAnhNgheThuat.ChamDiem" %>

<!DOCTYPE html>

<html>
<head runat="server">
    <title>Chấm điểm</title>
</head>

<body style="font-family:Arial;text-align:center;background:#f2f2f2;">

<form id="form1" runat="server">

<h1>CHẤM ĐIỂM TÁC PHẨM</h1>

<asp:GridView ID="gvBaiThi" runat="server"></asp:GridView>

<br />

Mã bài:

<asp:TextBox ID="txtMaBai" runat="server"></asp:TextBox>

<br /><br />

Điểm:

<asp:TextBox ID="txtDiem" runat="server"></asp:TextBox>

<br /><br />

Nhận xét:

<br />

<asp:TextBox
ID="txtNhanXet"
runat="server"
TextMode="MultiLine"
Width="400px"
Height="80px">
</asp:TextBox>

<br /><br />

<asp:Button
ID="btnLuu"
runat="server"
Text="Lưu điểm"
OnClick="btnLuu_Click" />

<br /><br />
    <br /><br />

<a href="Default.aspx"
   style="font-size:18px;
          color:#005baa;
          text-decoration:none;
          font-weight:bold;">
    ← Trở về trang chủ
</a>

<asp:Label
ID="lblThongBao"
runat="server"
ForeColor="Green">
</asp:Label>

</form>

</body>
</html>