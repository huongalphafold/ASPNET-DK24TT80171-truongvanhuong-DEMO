﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ChamThiAnhNgheThuat
{
    public partial class ChamDiem : System.Web.UI.Page
    {
        string connStr =
        @"Data Source=HUONGTRUONG-PC\SQLEXPRESS;
          Initial Catalog=ChamThiAnhDB;
          Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadBaiThi();
            }
        }

        void LoadBaiThi()
        {
            SqlConnection conn =
                new SqlConnection(connStr);

            SqlDataAdapter da =
                new SqlDataAdapter(
                "SELECT * FROM BaiDuThi",
                conn);

            DataTable dt =
                new DataTable();

            da.Fill(dt);

            gvBaiThi.DataSource = dt;
            gvBaiThi.DataBind();
        }

        protected void btnLuu_Click(object sender, EventArgs e)
        {
            SqlConnection conn =
                new SqlConnection(connStr);

            conn.Open();

            string sql =
            @"INSERT INTO ChamDiem
            (BaiDuThiId,Diem,NhanXet)
            VALUES
            (@BaiDuThiId,@Diem,@NhanXet)";

            SqlCommand cmd =
                new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue(
                "@BaiDuThiId",
                txtMaBai.Text);

            cmd.Parameters.AddWithValue(
                "@Diem",
                txtDiem.Text);

            cmd.Parameters.AddWithValue(
                "@NhanXet",
                txtNhanXet.Text);

            cmd.ExecuteNonQuery();

            conn.Close();

            lblThongBao.Text =
                "Lưu điểm thành công!";
        }
    }
}