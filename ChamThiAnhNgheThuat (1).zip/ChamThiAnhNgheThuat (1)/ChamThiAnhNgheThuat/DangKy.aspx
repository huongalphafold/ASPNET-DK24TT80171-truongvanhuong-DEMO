﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DangKy.aspx.cs" Inherits="ChamThiAnhNgheThuat.DangKy" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Đăng ký thí sinh</title>
</head>

<body style="font-family:Arial; text-align:center; background:#f2f2f2; color:#003366;">

<form id="form1" runat="server">

<h1>ĐĂNG KÝ THÍ SINH</h1>

<div style="width:480px; margin:auto; background:white; padding:30px; border-radius:10px;">

    Họ tên:
    <asp:TextBox ID="txtHoTen" runat="server" Width="280px"></asp:TextBox>
    <br /><br />

    Email:
    <asp:TextBox ID="txtEmail" runat="server" Width="280px"></asp:TextBox>
    <br /><br />

    Số điện thoại:
    <asp:TextBox ID="txtSoDienThoai" runat="server" Width="280px"></asp:TextBox>
    <br /><br />

    <asp:Button ID="btnDangKy" runat="server" Text="Đăng ký" OnClick="btnDangKy_Click" />

    <br /><br />

    <asp:Label ID="lblThongBao" runat="server" ForeColor="Green"></asp:Label>

</div>

<br />

<a href="Default.aspx">← Quay lại trang chủ</a>

</form>

</body>
</html>