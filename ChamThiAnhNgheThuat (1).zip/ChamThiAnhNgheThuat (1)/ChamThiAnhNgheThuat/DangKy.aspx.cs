﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace ChamThiAnhNgheThuat
{
    public partial class DangKy : System.Web.UI.Page
    {
        protected void btnDangKy_Click(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["ChamThiAnhDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string sql = @"INSERT INTO ThiSinh(HoTen, Email, SoDienThoai)
                               VALUES(@HoTen, @Email, @SoDienThoai)";

                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@HoTen", txtHoTen.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                cmd.Parameters.AddWithValue("@SoDienThoai", txtSoDienThoai.Text.Trim());

                conn.Open();
                cmd.ExecuteNonQuery();

                lblThongBao.Text = "Đăng ký thí sinh thành công!";
            }
        }
    }
}