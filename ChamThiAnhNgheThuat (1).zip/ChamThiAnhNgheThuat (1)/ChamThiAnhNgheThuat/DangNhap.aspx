﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DangNhap.aspx.cs" Inherits="ChamThiAnhNgheThuat.DangNhap" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Đăng nhập</title>
</head>

<body style="font-family:Arial; text-align:center; margin-top:80px; background:#f2f2f2; color:#003366;">

<form id="form1" runat="server">

    <h1>ĐĂNG NHẬP HỆ THỐNG</h1>

    <table style="margin:auto; background:white; padding:30px; border-radius:10px;">
        <tr>
            <td>Tên đăng nhập:</td>
            <td>
                <asp:TextBox ID="txtTenDangNhap" runat="server" Style="padding:8px; width:220px;"></asp:TextBox>
            </td>
        </tr>

        <tr>
            <td>Mật khẩu:</td>
            <td>
                <asp:TextBox ID="txtMatKhau" runat="server" TextMode="Password" Style="padding:8px; width:220px;"></asp:TextBox>
            </td>
        </tr>

        <tr>
            <td colspan="2" style="text-align:center; padding-top:20px;">
                <asp:Button ID="btnDangNhap" runat="server"
                    Text="Đăng nhập"
                    OnClick="btnDangNhap_Click"
                    Style="padding:10px 30px; background:#003366; color:white; border:0; border-radius:6px;" />
            </td>
        </tr>
    </table>

    <br />

    <asp:Label ID="lblThongBao" runat="server" ForeColor="Red"></asp:Label>

    <br /><br />

    <a href="Default.aspx">← Quay lại trang chủ</a>

</form>

</body>
</html>