﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace ChamThiAnhNgheThuat
{
    public partial class DangNhap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDangNhap_Click(object sender, EventArgs e)
        {
            string connStr = ConfigurationManager.ConnectionStrings["ChamThiAnhDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string sql = "SELECT VaiTro FROM TaiKhoan WHERE TenDangNhap=@TenDangNhap AND MatKhau=@MatKhau";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@TenDangNhap", txtTenDangNhap.Text.Trim());
                cmd.Parameters.AddWithValue("@MatKhau", txtMatKhau.Text.Trim());

                conn.Open();

                object kq = cmd.ExecuteScalar();

                if (kq != null)
                {
                    Session["TenDangNhap"] = txtTenDangNhap.Text.Trim();
                    Session["VaiTro"] = kq.ToString();

                    Response.Redirect("Default.aspx");
                }
                else
                {
                    lblThongBao.Text = "Sai tên đăng nhập hoặc mật khẩu!";
                }
            }
        }
    }
}