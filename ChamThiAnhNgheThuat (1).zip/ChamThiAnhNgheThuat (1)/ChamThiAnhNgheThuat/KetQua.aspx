﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="KetQua.aspx.cs" Inherits="ChamThiAnhNgheThuat.KetQua" %>

<!DOCTYPE html>

<html>
<head runat="server">
    <title>Kết quả cuộc thi</title>
</head>

<body style="font-family:Arial; text-align:center; background:#f2f2f2; color:#003366;">

<form id="form1" runat="server">

<h1>KẾT QUẢ CUỘC THI ẢNH NGHỆ THUẬT</h1>

<div style="width:900px; margin:auto; background:white; padding:30px; border-radius:10px; box-shadow:0 0 15px #ddd;">

    <h2>DANH SÁCH TÁC PHẨM</h2>

    <asp:GridView ID="gvKetQua"
        runat="server"
        Width="800px"
        AutoGenerateColumns="true"
        HorizontalAlign="Center">
    </asp:GridView>

    <br /><br />

    <a href="Default.aspx">
        ← Quay lại trang chủ
    </a>

</div>

</form>

</body>
</html>