﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ChamThiAnhNgheThuat
{
    public partial class KetQua : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadKetQua();
            }
        }

        private void LoadKetQua()
        {
            string connStr =
                ConfigurationManager.ConnectionStrings["ChamThiAnhDB"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string sql = @"
                SELECT
                    B.TenTacPham,
                    B.TacGia,
                    C.Diem,
                    C.NhanXet
                FROM BaiDuThi B
                INNER JOIN ChamDiem C
                ON B.Id = C.BaiDuThiId
                ORDER BY C.Diem DESC";

                SqlDataAdapter da = new SqlDataAdapter(sql, conn);

                DataTable dt = new DataTable();

                da.Fill(dt);

                gvKetQua.DataSource = dt;
                gvKetQua.DataBind();
            }
        }
    }
}