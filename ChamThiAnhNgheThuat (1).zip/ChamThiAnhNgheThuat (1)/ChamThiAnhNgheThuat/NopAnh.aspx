﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="NopAnh.aspx.cs" Inherits="ChamThiAnhNgheThuat.NopAnh" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Nộp ảnh dự thi</title>
</head>
<body style="font-family:Arial; text-align:center; margin-top:60px; background:#f2f2f2; color:#003366;">

<form id="form1" runat="server">

    <h1>NỘP ẢNH DỰ THI</h1>

    <table style="margin:auto; background:white; padding:30px; border-radius:10px;">
        <tr>
            <td>Tên tác phẩm:</td>
            <td><asp:TextBox ID="txtTenTacPham" runat="server"></asp:TextBox></td>
        </tr>

        <tr>
            <td>Tác giả:</td>
            <td><asp:TextBox ID="txtTacGia" runat="server"></asp:TextBox></td>
        </tr>

        <tr>
            <td>Chọn ảnh:</td>
            <td><asp:FileUpload ID="FileUpload1" runat="server" /></td>
        </tr>

        <tr>
            <td colspan="2" style="text-align:center; padding-top:20px;">
                <asp:Button ID="btnNop" runat="server" Text="Nộp ảnh" OnClick="btnNop_Click" />
            </td>
        </tr>
    </table>

    <br />

    <asp:Label ID="lblThongBao" runat="server" ForeColor="Green"></asp:Label>

    <br /><br />

    <a href="Default.aspx">← Quay lại trang chủ</a>

</form>

</body>
</html>