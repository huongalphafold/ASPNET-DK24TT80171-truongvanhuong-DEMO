﻿using System;
using System.Data.SqlClient;

namespace ChamThiAnhNgheThuat
{
    public partial class NopAnh : System.Web.UI.Page
    {
        protected void btnNop_Click(object sender, EventArgs e)
        {
            string connStr =
            @"Data Source=HUONGTRUONG-PC\SQLEXPRESS;
              Initial Catalog=ChamThiAnhDB;
              Integrated Security=True";

            SqlConnection conn =
                new SqlConnection(connStr);

            conn.Open();

            string sql =
            "INSERT INTO BaiDuThi(TenTacPham,TacGia,DuongDanAnh) " +
            "VALUES(@TenTacPham,@TacGia,@DuongDanAnh)";

            SqlCommand cmd =
                new SqlCommand(sql, conn);

            cmd.Parameters.AddWithValue("@TenTacPham",
                txtTenTacPham.Text);

            cmd.Parameters.AddWithValue("@TacGia",
                txtTacGia.Text);

            cmd.Parameters.AddWithValue("@DuongDanAnh",
                FileUpload1.FileName);

            cmd.ExecuteNonQuery();

            conn.Close();

            lblThongBao.Text =
                "Nộp ảnh thành công!";
        }
    }
}